#!/bin/sh
java -cp bin PruebaGestor
