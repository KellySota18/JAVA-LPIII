#!/bin/sh
# Compila el proyecto. Si falta el driver SQLite JDBC, lo descarga en lib/
if [ ! -f lib/sqlite-jdbc-3.41.2.2.jar ]; then
  echo "Descargando driver SQLite JDBC..."
  curl -L -o lib/sqlite-jdbc-3.41.2.2.jar https://repo1.maven.org/maven2/org/xerial/sqlite-jdbc/3.41.2.2/sqlite-jdbc-3.41.2.2.jar || { echo "No se pudo descargar el driver"; exit 1; }
fi
mkdir -p bin
javac -encoding UTF-8 -d bin src/*.java test/*.java && echo "Compilacion correcta. Clases en bin/"
