@echo off
java -cp "bin;lib\*" Ejercicio1
