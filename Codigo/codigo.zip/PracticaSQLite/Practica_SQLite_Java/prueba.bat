@echo off
java -cp bin PruebaGestor
