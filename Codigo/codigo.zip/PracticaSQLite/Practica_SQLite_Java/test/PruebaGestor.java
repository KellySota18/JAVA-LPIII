import java.util.List;

/**
 * Pruebas de la clase gestora (Ejercicio 2). No necesitan base de datos ni librerías externas:
 * trabajan sobre los datos de ejemplo cargados en el arreglo.
 *
 * Uso (desde la carpeta del proyecto, después de compilar):
 *     java -cp bin PruebaGestor
 */
public class PruebaGestor {

    private static int ok = 0;
    private static int fallos = 0;

    public static void main(String[] args) {
        GestorProductos g = new GestorProductos();
        List<Producto> datos = ProductoDAO.ejemplos();
        for (int i = 0; i < datos.size(); i++) {
            datos.get(i).setId(i + 1);          // simula los ids que asignaría la BD
        }
        g.cargar(datos);

        // Sin parámetros = SELECT * FROM productos
        GestorProductos.Resultado r = g.consultar(null, null, null, null, null, true, 0);
        verificar("SELECT * devuelve los 10 registros", r.getFilas().size() == 10);
        verificar("SELECT * devuelve las 4 columnas", r.getColumnas().length == 4);

        // a) campos a mostrar
        r = g.consultar(new String[]{"nombre", "precio"}, null, null, null, null, true, 0);
        verificar("a) solo 2 columnas", r.getColumnas().length == 2
                && r.getColumnas()[0].equals("nombre") && r.getColumnas()[1].equals("precio"));
        verificar("a) fila tiene 2 valores", r.getFilas().get(0).length == 2);

        // b) condición numérica
        r = g.consultar(new String[]{"nombre"}, "precio", ">", "500", null, true, 0);
        verificar("b) precio > 500 -> 3 productos", r.getFilas().size() == 3);

        // b) condición de texto (igualdad sin distinguir mayúsculas)
        r = g.consultar(new String[]{"nombre"}, "categoria", "=", "accesorios", null, true, 0);
        verificar("b) categoria = accesorios -> 3 productos", r.getFilas().size() == 3);

        // b) LIKE
        r = g.consultar(new String[]{"nombre"}, "nombre", "LIKE", "%epson%", null, true, 0);
        verificar("b) nombre LIKE %epson% -> 2 productos", r.getFilas().size() == 2);

        // b) <> y <=
        r = g.consultar(null, "categoria", "<>", "Accesorios", null, true, 0);
        verificar("b) categoria <> Accesorios -> 7 productos", r.getFilas().size() == 7);
        r = g.consultar(null, "id", "<=", "3", null, true, 0);
        verificar("b) id <= 3 -> 3 productos", r.getFilas().size() == 3);

        // c) orden descendente por precio
        r = g.consultar(new String[]{"nombre", "precio"}, null, null, null, "precio", false, 0);
        double primero = (Double) r.getFilas().get(0)[1];
        double ultimo = (Double) r.getFilas().get(9)[1];
        verificar("c) precio DESC: primero 2450.00 y ultimo 29.00", primero == 2450.00 && ultimo == 29.00);

        // c) orden ascendente por nombre
        r = g.consultar(new String[]{"nombre"}, null, null, null, "nombre", true, 0);
        verificar("c) nombre ASC: empieza con 'Disco SSD 500 GB'",
                "Disco SSD 500 GB".equals(r.getFilas().get(0)[0]));

        // d) límite
        r = g.consultar(null, null, null, null, "precio", false, 3);
        verificar("d) LIMIT 3 -> 3 filas", r.getFilas().size() == 3);

        // Combinación completa: WHERE + ORDER BY + LIMIT + proyección
        //   SELECT nombre, precio FROM productos WHERE precio < 300 ORDER BY precio DESC LIMIT 2
        r = g.consultar(new String[]{"nombre", "precio"}, "precio", "<", "300", "precio", false, 2);
        verificar("combinada: 2 filas", r.getFilas().size() == 2);
        verificar("combinada: 1ra = Disco SSD (215.00)",
                "Disco SSD 500 GB".equals(r.getFilas().get(0)[0]) && (Double) r.getFilas().get(0)[1] == 215.00);
        verificar("combinada: 2da = Teclado mecanico (189.00)",
                "Teclado mecanico".equals(r.getFilas().get(1)[0]));

        // El arreglo original no se modifica al ordenar
        verificar("el arreglo original conserva su orden",
                g.getArreglo()[0].getNombre().equals("Laptop Lenovo IdeaPad"));

        // Errores de validación
        verificarError("campo inexistente", () -> g.consultar(new String[]{"stock"}, null, null, null, null, true, 0));
        verificarError("operador invalido", () -> g.consultar(null, "precio", "~", "5", null, true, 0));
        verificarError("valor no numerico en campo numerico", () -> g.consultar(null, "precio", ">", "abc", null, true, 0));
        verificarError("campo de orden inexistente", () -> g.consultar(null, null, null, null, "color", true, 0));

        // SQL equivalente
        String sql = g.sqlEquivalente(new String[]{"nombre", "precio"}, "precio", "<", "300", "precio", false, 2);
        verificar("SQL equivalente correcto",
                sql.equals("SELECT nombre, precio FROM productos WHERE precio < 300 ORDER BY precio DESC LIMIT 2"));

        System.out.println();
        System.out.println("Resultado: " + ok + " correctas, " + fallos + " fallidas.");
        if (fallos > 0) {
            System.exit(1);
        }
    }

    private static void verificar(String descripcion, boolean condicion) {
        if (condicion) {
            ok++;
            System.out.println("[OK]    " + descripcion);
        } else {
            fallos++;
            System.out.println("[FALLO] " + descripcion);
        }
    }

    private static void verificarError(String descripcion, Runnable accion) {
        try {
            accion.run();
            fallos++;
            System.out.println("[FALLO] debia lanzar error: " + descripcion);
        } catch (IllegalArgumentException e) {
            ok++;
            System.out.println("[OK]    error esperado (" + descripcion + "): " + e.getMessage());
        }
    }
}
