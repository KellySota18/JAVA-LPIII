#!/bin/sh
java -cp "bin:lib/*" Ejercicio2
