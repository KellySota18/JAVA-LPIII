//Representa un registro de la tabla "productos" (4 campos).
 //id        INTEGER  (clave primaria, autoincremental)
 //  nombre    TEXT
 //  categoria TEXT
 //  precio    REAL
 
public class Producto {
//Nombres de los campos de la tabla, en el mismo orden que las columnas
    public static final String[] CAMPOS = {"id", "nombre", "categoria", "precio"};
    private int id;
    private String nombre;
    private String categoria;
    private double precio;
    public Producto(int id, String nombre, String categoria, double precio) {
        this.id = id;
        this.nombre = nombre;
        this.categoria = categoria;
        this.precio = precio;
    }

//Constructor para registros nuevos (el id lo asigna la base de datos)
    public Producto(String nombre, String categoria, double precio) {
        this(0, nombre, categoria, precio);
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getCategoria() { return categoria; }
    public double getPrecio() { return precio; }

    public void setId(int id) { this.id = id; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setCategoria(String categoria) { this.categoria = categoria; }
    public void setPrecio(double precio) { this.precio = precio; }

    //Devuelve el valor de un campo a partir de su nombre (id, nombre, categoria, precio)
    public Object valor(String campo) {
        switch (campo) {
            case "id":        return id;
            case "nombre":    return nombre;
            case "categoria": return categoria;
            case "precio":    return precio;
            default:
                throw new IllegalArgumentException("Campo desconocido: " + campo);
        }
    }

    @Override
    public String toString() {
        return String.format("Producto{id=%d, nombre='%s', categoria='%s', precio=%.2f}",
                id, nombre, categoria, precio);
    }
}
