import java.util.Scanner;
//Utilidades para leer datos por consola con validación. 
public class Consola {
    private final Scanner in;
    public Consola(Scanner in) {
        this.in = in;
    }
    public String leerLinea(String mensaje) {
        System.out.print(mensaje);
        return in.nextLine().trim();
    }
    //Lee un texto que no puede estar vacío
    public String leerTexto(String mensaje) {
        while (true) {
            String s = leerLinea(mensaje);
            if (!s.isEmpty()) {
                return s;
            }
            System.out.println("El valor no puede estar vacio");
        }
    }
    //Lee un entero; repite la pregunta mientras el dato no sea válido
    public int leerEntero(String mensaje) {
        while (true) {
            String s = leerLinea(mensaje);
            try {
                return Integer.parseInt(s);
            } catch (NumberFormatException e) {
                System.out.println("Ingrese un numero entero valido");
            }
        }
    }

    //Lee un decimal positivo o cero (acepta coma o punto como separador)
    public double leerPrecio(String mensaje) {
        while (true) {
            String s = leerLinea(mensaje).replace(',', '.');
            try {
                double v = Double.parseDouble(s);
                if (v >= 0) {
                    return v;
                }
                System.out.println("El precio no puede ser negativo");
            } catch (NumberFormatException e) {
                System.out.println("  Ingrese un numero valido (ej. 25.50).");
            }
        }
    }

    //Pregunta sí/no. Devuelve true si la respuesta empieza con 's'. */
    public boolean confirmarSiNo(String mensaje) {
        return leerLinea(mensaje + " (s/n): ").toLowerCase().startsWith("s");
    }
}
