import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class ConexionDB {
    public static final String URL = "jdbc:sqlite:tienda.db";
    private ConexionDB() { }
   // @param autoCommit false = el programa decide cuándo hacer commit/rollback
     
    public static Connection abrir(boolean autoCommit) throws SQLException {
        Connection con = DriverManager.getConnection(URL);
        con.setAutoCommit(autoCommit);
        return con;
    }
}
