import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Pattern;
 //EJERCICIO 2 - Clase gestora.
public class GestorProductos {
    //Operadores admitidos en la condición.
    public static final String[] OPERADORES = {"=", "<>", ">", "<", ">=", "<=", "LIKE"};
    private Producto[] arreglo = new Producto[0];
    //Reemplaza el contenido del arreglo con los registros recibidos
    public void cargar(List<Producto> registros) {
        arreglo = registros.toArray(new Producto[0]);
    }
    public int cantidad() {
        return arreglo.length;
    }

    //Copia del arreglo (para que desde afuera no se modifique el original). 
    public Producto[] getArreglo() {
        return arreglo.clone();
    }
    // resultado
    //Resultado de una consulta: nombres de columnas + filas con los valores. 
    public static class Resultado {
        private final String[] columnas;
        private final List<Object[]> filas;
        Resultado(String[] columnas, List<Object[]> filas) {
            this.columnas = columnas;
            this.filas = filas;
        }

        public String[] getColumnas() { return columnas.clone(); }
        public List<Object[]> getFilas() { return filas; }
        //Imprime el resultado como una tabla alineada
        public void imprimir(PrintStream out) {
            if (filas.isEmpty()) {
                out.println("(sin resultados)");
                return;
            }
            int[] ancho = new int[columnas.length];
            for (int c = 0; c < columnas.length; c++) {
                ancho[c] = columnas[c].length();
                for (Object[] fila : filas) {
                    ancho[c] = Math.max(ancho[c], texto(fila[c]).length());
                }
            }
            StringBuilder linea = new StringBuilder();
            for (int c = 0; c < columnas.length; c++) {
                out.print(String.format("%-" + ancho[c] + "s  ", columnas[c].toUpperCase()));
                linea.append("-".repeat(ancho[c])).append("  ");
            }
            out.println();
            out.println(linea);
            for (Object[] fila : filas) {
                for (int c = 0; c < columnas.length; c++) {
                    out.print(String.format("%-" + ancho[c] + "s  ", texto(fila[c])));
                }
                out.println();
            }
            out.println("(" + filas.size() + " fila(s))");
        }

        private static String texto(Object v) {
            return (v instanceof Double) ? String.format("%.2f", (Double) v) : String.valueOf(v);
        }
    }
//Consulta
//Consulta el arreglo de objetos con las mismas características que una sentencia SQL.
// @param campos         (a) campos a mostrar; null o vacío = todos (equivale a SELECT *)
//@param campoCondicion (b) campo que debe cumplir una condición; null o vacío = sin condición
//@param operador       operador de la condición: =, <>, >, <, >=, <=, LIKE
//@param valorCondicion valor contra el que se compara (con LIKE se admiten % y _)
//@param campoOrden     (c) campo por el que se ordena; null o vacío = sin orden
//@param ascendente     true = ascendente (ASC), false = descendente (DESC)
//@param limite         (d) máximo de registros a mostrar; 0 o negativo = sin límite
//@throws IllegalArgumentException si algún campo, operador o valor no es válido
    public Resultado consultar(String[] campos,
                               String campoCondicion, String operador, String valorCondicion,
                               String campoOrden, boolean ascendente,
                               int limite) {

        String[] columnas = normalizarCampos(campos);
       // 1) WHERE
        List<Producto> seleccion = new ArrayList<>();
        boolean hayCondicion = campoCondicion != null && !campoCondicion.trim().isEmpty();
        String campoCond = hayCondicion ? validarCampo(campoCondicion) : null;
        String op = hayCondicion ? validarOperador(operador) : null;
        for (Producto p : arreglo) {
            if (!hayCondicion || cumple(p, campoCond, op, valorCondicion)) {
                seleccion.add(p);
            }
        }

        // 2) ORDER BY
        if (campoOrden != null && !campoOrden.trim().isEmpty()) {
            String campo = validarCampo(campoOrden);
            Comparator<Producto> cmp = comparadorPor(campo);
            seleccion.sort(ascendente ? cmp : cmp.reversed());
        }

        // 3) LIMIT
        if (limite > 0 && seleccion.size() > limite) {
            seleccion = seleccion.subList(0, limite);
        }

        // 4) SELECT (proyección de los campos pedidos)
        List<Object[]> filas = new ArrayList<>();
        for (Producto p : seleccion) {
            Object[] fila = new Object[columnas.length];
            for (int i = 0; i < columnas.length; i++) {
                fila[i] = p.valor(columnas[i]);
            }
            filas.add(fila);
        }
        return new Resultado(columnas, filas);
    }

 //Devuelve la sentencia SQL equivalente (solo informativa, para comparar con la consulta en Java).

    public String sqlEquivalente(String[] campos,
                                 String campoCondicion, String operador, String valorCondicion,
                                 String campoOrden, boolean ascendente,
                                 int limite) {
        String[] columnas = normalizarCampos(campos);
        StringBuilder sql = new StringBuilder("SELECT ");
        sql.append(columnas.length == Producto.CAMPOS.length && Arrays.equals(columnas, Producto.CAMPOS)
                ? "*" : String.join(", ", columnas));
        sql.append(" FROM productos");
        if (campoCondicion != null && !campoCondicion.trim().isEmpty()) {
            String campo = validarCampo(campoCondicion);
            String op = validarOperador(operador);
            if (valorCondicion == null) {
                throw new IllegalArgumentException("Falta el valor de la condicion.");
            }
            String valor = valorCondicion.trim();
            if (esNumerico(campo)) {
                try {
                    Double.parseDouble(valor.replace(',', '.'));
                } catch (NumberFormatException e) {
                    throw new IllegalArgumentException("El campo '" + campo
                            + "' es numerico y el valor '" + valor + "' no es un numero.");
                }
                valor = valor.replace(',', '.');
            } else {
                valor = "'" + valor + "'";
            }
            sql.append(" WHERE ").append(campo).append(' ').append(op).append(' ').append(valor);
        }
        if (campoOrden != null && !campoOrden.trim().isEmpty()) {
            sql.append(" ORDER BY ").append(validarCampo(campoOrden)).append(ascendente ? " ASC" : " DESC");
        }
        if (limite > 0) {
            sql.append(" LIMIT ").append(limite);
        }
        return sql.toString();
    }
    // Auxiliares
    private static boolean esNumerico(String campo) {
        return campo.equals("id") || campo.equals("precio");
    }
    private static String validarCampo(String campo) {
        String c = campo.trim().toLowerCase();
        for (String valido : Producto.CAMPOS) {
            if (valido.equals(c)) {
                return c;
            }
        }
        throw new IllegalArgumentException("Campo no valido: '" + campo + "'. Campos disponibles: "
                + String.join(", ", Producto.CAMPOS));
    }

    private static String validarOperador(String operador) {
        if (operador == null) {
            throw new IllegalArgumentException("Falta el operador de la condicion.");
        }
        String op = operador.trim().toUpperCase();
        if (op.equals("!=")) {
            op = "<>";
        }
        for (String valido : OPERADORES) {
            if (valido.equals(op)) {
                return op;
            }
        }
        throw new IllegalArgumentException("Operador no valido: '" + operador + "'. Operadores: "
                + String.join(" ", OPERADORES));
    }

    private static String[] normalizarCampos(String[] campos) {
        if (campos == null || campos.length == 0) {
            return Producto.CAMPOS.clone();
        }
        List<String> lista = new ArrayList<>();
        for (String c : campos) {
            if (c != null && !c.trim().isEmpty()) {
                String campo = validarCampo(c);
                if (!lista.contains(campo)) {
                    lista.add(campo);
                }
            }
        }
        return lista.isEmpty() ? Producto.CAMPOS.clone() : lista.toArray(new String[0]);
    }
    //Evalúa la condición "campo operador valor" sobre un producto. 
    private static boolean cumple(Producto p, String campo, String op, String valorTexto) {
        if (valorTexto == null) {
            throw new IllegalArgumentException("Falta el valor de la condicion.");
        }
        String valor = valorTexto.trim();
        Object actual = p.valor(campo);

        if (op.equals("LIKE")) {
            return patronLike(valor).matcher(String.valueOf(actual)).matches();
        }
        int comparacion;
        if (esNumerico(campo)) {
            double buscado;
            try {
                buscado = Double.parseDouble(valor.replace(',', '.'));
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("El campo '" + campo
                        + "' es numerico y el valor '" + valor + "' no es un numero.");
            }
            comparacion = Double.compare(((Number) actual).doubleValue(), buscado);
        } else {
            comparacion = ((String) actual).compareToIgnoreCase(valor);
        }
        switch (op) {
            case "=":  return comparacion == 0;
            case "<>": return comparacion != 0;
            case ">":  return comparacion > 0;
            case "<":  return comparacion < 0;
            case ">=": return comparacion >= 0;
            case "<=": return comparacion <= 0;
            default:   return false;
        }
    }
    // Convierte un patrón LIKE de SQL (% = cualquier texto, _ = un carácter) en expresión regular. 
    private static Pattern patronLike(String like) {
        StringBuilder regex = new StringBuilder();
        StringBuilder literal = new StringBuilder();
        for (char ch : like.toCharArray()) {
            if (ch == '%' || ch == '_') {
                if (literal.length() > 0) {
                    regex.append(Pattern.quote(literal.toString()));
                    literal.setLength(0);
                }
                regex.append(ch == '%' ? ".*" : ".");
            } else {
                literal.append(ch);
            }
        }
        if (literal.length() > 0) {
            regex.append(Pattern.quote(literal.toString()));
        }
        return Pattern.compile(regex.toString(), Pattern.CASE_INSENSITIVE | Pattern.DOTALL);
    }

    private static Comparator<Producto> comparadorPor(String campo) {
        if (campo.equals("id")) {
            return Comparator.comparingInt(Producto::getId);
        } else if (campo.equals("precio")) {
            return Comparator.comparingDouble(Producto::getPrecio);
        } else if (campo.equals("nombre")) {
            return Comparator.comparing(Producto::getNombre, String.CASE_INSENSITIVE_ORDER);
        } else {
            return Comparator.comparing(Producto::getCategoria, String.CASE_INSENSITIVE_ORDER);
        }
    }
}
