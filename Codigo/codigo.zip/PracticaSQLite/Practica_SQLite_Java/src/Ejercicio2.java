import java.sql.Connection;
import java.sql.SQLException;
import java.util.NoSuchElementException;
import java.util.Scanner;
public class Ejercicio2 {
    public static void main(String[] args) {
        try (Connection con = ConexionDB.abrir(true);
             Scanner scanner = new Scanner(System.in)) {
            ProductoDAO dao = new ProductoDAO(con);
            dao.inicializar();
            Consola consola = new Consola(scanner);
            GestorProductos gestor = new GestorProductos();
            if (dao.contar() == 0) {
                System.out.println("La tabla 'productos' esta vacia.");
                if (consola.confirmarSiNo("Desea cargar 10 productos de ejemplo")) {
                    for (Producto p : ProductoDAO.ejemplos()) {
                        dao.insertar(p);
                    }
                    System.out.println("Datos de ejemplo cargados.");
                }
            }
            gestor.cargar(dao.listar());
            System.out.println("Registros cargados en el arreglo: " + gestor.cantidad());

            int opcion;
            do {
                System.out.println();
                System.out.println("=========== GESTOR DE PRODUCTOS (arreglo) ===========");
                System.out.println(" 1. Mostrar todo el arreglo");
                System.out.println(" 2. Hacer una consulta");
                System.out.println(" 3. Recargar el arreglo desde la base de datos");
                System.out.println(" 0. Salir");
                System.out.println("=====================================================");
                opcion = consola.leerEntero("Elija una opcion: ");

                switch (opcion) {
                    case 1:
                        gestor.consultar(null, null, null, null, null, true, 0)
                              .imprimir(System.out);
                        break;
                    case 2:
                        consultaInteractiva(gestor, consola);
                        break;
                    case 3:
                        gestor.cargar(dao.listar());
                        System.out.println("Arreglo recargado: " + gestor.cantidad() + " registro(s).");
                        break;
                    case 0:
                        System.out.println("Hasta pronto.");
                        break;
                    default:
                        System.out.println("Opcion no valida.");
                }
            } while (opcion != 0);

        } catch (NoSuchElementException e) {
            System.out.println("\nSe cerro la entrada de datos. Fin del programa.");
        } catch (SQLException e) {
            System.out.println("Error de base de datos: " + e.getMessage());
            System.out.println("Verifique que el driver sqlite-jdbc este en la carpeta lib/.");
        }
    }

    //Pide al usuario los parámetros (a), (b), (c) y (d) y ejecuta la consulta sobre el arreglo
    private static void consultaInteractiva(GestorProductos gestor, Consola consola) {
        System.out.println("--- Consulta personalizada ---");
        System.out.println("Campos disponibles: " + String.join(", ", Producto.CAMPOS));

        // a) campos a mostrar
        String entradaCampos = consola.leerLinea("a) Campos a mostrar, separados por coma (Enter = todos): ");
        String[] campos = entradaCampos.isEmpty() ? null : entradaCampos.split(",");

        // b) condición
        String campoCond = null, operador = null, valorCond = null;
        if (consola.confirmarSiNo("b) Desea aplicar una condicion")) {
            campoCond = consola.leerTexto("   Campo: ");
            operador = consola.leerTexto("   Operador (" + String.join(" ", GestorProductos.OPERADORES) + "): ");
            valorCond = consola.leerTexto("   Valor: ");
        }

        // c) orden
        String campoOrden = null;
        boolean ascendente = true;
        if (consola.confirmarSiNo("c) Desea ordenar los resultados")) {
            campoOrden = consola.leerTexto("   Campo de orden: ");
            ascendente = !consola.leerLinea("   Ascendente (A) o Descendente (D) [A]: ")
                                 .toUpperCase().startsWith("D");
        }

        // d) límite
        int limite = 0;
        if (consola.confirmarSiNo("d) Desea limitar la cantidad de registros")) {
            limite = consola.leerEntero("   Cantidad maxima de registros: ");
        }

        try {
            System.out.println();
            System.out.println("SQL equivalente: "
                    + gestor.sqlEquivalente(campos, campoCond, operador, valorCond, campoOrden, ascendente, limite));
            System.out.println();
            gestor.consultar(campos, campoCond, operador, valorCond, campoOrden, ascendente, limite)
                  .imprimir(System.out);
        } catch (IllegalArgumentException e) {
            System.out.println("Consulta no valida: " + e.getMessage());
        }
    }
}
