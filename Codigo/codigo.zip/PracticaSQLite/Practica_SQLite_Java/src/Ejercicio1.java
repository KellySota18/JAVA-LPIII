import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Scanner;
public class Ejercicio1 {
    //Clave que el usuario debe ingresar para confirmar los cambios
    private static final String CLAVE = "1234";
    public static void main(String[] args) {
        try (Connection con = ConexionDB.abrir(false);
             Scanner scanner = new Scanner(System.in)) {
            ProductoDAO dao = new ProductoDAO(con);
            dao.inicializar();
            Consola consola = new Consola(scanner);
            int opcion;
            do {
                mostrarMenu();
                opcion = consola.leerEntero("Elija una opcion: ");
                try {
                    switch (opcion) {
                        case 1: ingresar(dao, consola); break;
                        case 2: borrar(dao, consola); break;
                        case 3: actualizar(dao, consola); break;
                        case 4: mostrar(dao); break;
                        case 5: cargarEjemplos(dao, consola); break;
                        case 0: System.out.println("Hasta pronto."); break;
                        default: System.out.println("Opcion no valida");
                    }
                } catch (SQLException e) {
                    // Ante cualquier error de BD se descarta lo pendiente.
                    System.out.println("Error de base de datos: " + e.getMessage());
                    try {
                        dao.revertir();
                        System.out.println("Se revirtieron los cambios pendientes.");
                    } catch (SQLException ex) {
                        System.out.println("No se pudo revertir: " + ex.getMessage());
                    }
                }
            } while (opcion != 0);

        } catch (NoSuchElementException e) {
            System.out.println("\nSe cerro la entrada de datos. Fin del programa.");
        } catch (SQLException e) {
            System.out.println("No se pudo abrir la base de datos: " + e.getMessage());
            System.out.println("Verifique que el driver sqlite-jdbc este en la carpeta lib/.");
        }
    }

    private static void mostrarMenu() {
        System.out.println();
        System.out.println("=========== PRODUCTOS (SQLite) ===========");
        System.out.println(" 1. Ingresar un producto");
        System.out.println(" 2. Borrar un producto");
        System.out.println(" 3. Actualizar un producto");
        System.out.println(" 4. Mostrar todos los productos");
        System.out.println(" 5. Cargar datos de ejemplo");
        System.out.println(" 0. Salir");
        System.out.println("==========================================");
    }

    // Operaciones
    private static void ingresar(ProductoDAO dao, Consola consola) throws SQLException {
        System.out.println("--- Ingresar producto ---");
        String nombre = consola.leerTexto("Nombre: ");
        String categoria = consola.leerTexto("Categoria: ");
        double precio = consola.leerPrecio("Precio: ");
        int id = dao.insertar(new Producto(nombre, categoria, precio));
        System.out.println("Producto insertado (pendiente de confirmacion), id = " + id);
        confirmarCambios(dao, consola);
    }
    private static void borrar(ProductoDAO dao, Consola consola) throws SQLException {
        System.out.println("--- Borrar producto ---");
        int id = consola.leerEntero("Id del producto a borrar: ");
        Producto p = dao.buscar(id);
        if (p == null) {
            System.out.println("No existe un producto con id " + id + ". No hay cambios.");
            return;
        }
        System.out.println("Se borrara: " + p);
        dao.eliminar(id);
        confirmarCambios(dao, consola);
    }

    private static void actualizar(ProductoDAO dao, Consola consola) throws SQLException {
        System.out.println("--- Actualizar producto ---");
        int id = consola.leerEntero("Id del producto a actualizar: ");
        Producto p = dao.buscar(id);
        if (p == null) {
            System.out.println("No existe un producto con id " + id + ". No hay cambios.");
            return;
        }
        System.out.println("Datos actuales: " + p);
        System.out.println("(Presione Enter para conservar el valor actual)");

        String nombre = consola.leerLinea("Nuevo nombre [" + p.getNombre() + "]: ");
        if (!nombre.isEmpty()) p.setNombre(nombre);

        String categoria = consola.leerLinea("Nueva categoria [" + p.getCategoria() + "]: ");
        if (!categoria.isEmpty()) p.setCategoria(categoria);

        String precio = consola.leerLinea("Nuevo precio [" + p.getPrecio() + "]: ");
        if (!precio.isEmpty()) {
            try {
                double v = Double.parseDouble(precio.replace(',', '.'));
                if (v < 0) throw new NumberFormatException();
                p.setPrecio(v);
            } catch (NumberFormatException e) {
                System.out.println("Precio invalido. Se conserva el precio actual.");
            }
        }

        dao.actualizar(p);
        System.out.println("Producto actualizado (pendiente de confirmacion).");
        confirmarCambios(dao, consola);
    }

    private static void mostrar(ProductoDAO dao) throws SQLException {
        List<Producto> lista = dao.listar();
        System.out.println("--- Productos registrados: " + lista.size() + " ---");
        if (lista.isEmpty()) {
            System.out.println("(la tabla esta vacia)");
            return;
        }
        System.out.printf("%-5s %-26s %-16s %10s%n", "ID", "NOMBRE", "CATEGORIA", "PRECIO");
        System.out.println("-".repeat(61));
        for (Producto p : lista) {
            System.out.printf("%-5d %-26s %-16s %10.2f%n",
                    p.getId(), p.getNombre(), p.getCategoria(), p.getPrecio());
        }
    }

    private static void cargarEjemplos(ProductoDAO dao, Consola consola) throws SQLException {
        List<Producto> ejemplos = ProductoDAO.ejemplos();
        for (Producto p : ejemplos) {
            dao.insertar(p);
        }
        System.out.println("Se insertaron " + ejemplos.size() + " productos de ejemplo (pendientes).");
        confirmarCambios(dao, consola);
    }
 
    private static void confirmarCambios(ProductoDAO dao, Consola consola) throws SQLException {
        String clave = consola.leerLinea("Ingrese la clave para confirmar los cambios: ");
        if (CLAVE.equals(clave)) {
            dao.confirmar();
            System.out.println("Clave correcta: cambios CONFIRMADOS (commit).");
        } else {
            dao.revertir();
            System.out.println("Clave incorrecta: cambios REVERTIDOS (rollback).");
        }
    }
}
