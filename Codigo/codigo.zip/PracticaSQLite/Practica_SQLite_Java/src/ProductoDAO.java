import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
//Acceso a datos de la tabla "productos".
//Las operaciones que modifican datos (insertar, eliminar, actualizar) NO hacen commit:
//quedan pendientes en la transacción hasta que se llame a confirmar() o revertir().
public class ProductoDAO {
    private final Connection con;
    public ProductoDAO(Connection con) {
        this.con = con;
    }
//Crea la tabla si no existe y confirma la creación. 
    public void inicializar() throws SQLException {
        String ddl = "CREATE TABLE IF NOT EXISTS productos ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "nombre TEXT NOT NULL, "
                + "categoria TEXT NOT NULL, "
                + "precio REAL NOT NULL)";
        try (Statement st = con.createStatement()) {
            st.execute(ddl);
        }
        if (!con.getAutoCommit()) {
            con.commit();
        }
    }

//Inserta un producto y devuelve el id generado (la operación queda pendiente).
    public int insertar(Producto p) throws SQLException {
        String sql = "INSERT INTO productos (nombre, categoria, precio) VALUES (?, ?, ?)";
        try (PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getCategoria());
            ps.setDouble(3, p.getPrecio());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                return keys.next() ? keys.getInt(1) : -1;
            }
        }
    }

    /** Elimina el producto con ese id. Devuelve la cantidad de filas afectadas (0 o 1). */
    public int eliminar(int id) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement("DELETE FROM productos WHERE id = ?")) {
            ps.setInt(1, id);
            return ps.executeUpdate();
        }
    }

    /** Actualiza nombre, categoría y precio del producto. Devuelve filas afectadas (0 o 1). */
    public int actualizar(Producto p) throws SQLException {
        String sql = "UPDATE productos SET nombre = ?, categoria = ?, precio = ? WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getCategoria());
            ps.setDouble(3, p.getPrecio());
            ps.setInt(4, p.getId());
            return ps.executeUpdate();
        }
    }

    //Busca un producto por id; devuelve null si no existe 
    public Producto buscar(int id) throws SQLException {
        String sql = "SELECT id, nombre, categoria, precio FROM productos WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? mapear(rs) : null;
            }
        }
    }

    //Devuelve todos los productos ordenados por id. */
    public List<Producto> listar() throws SQLException {
        List<Producto> lista = new ArrayList<>();
        String sql = "SELECT id, nombre, categoria, precio FROM productos ORDER BY id";
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapear(rs));
            }
        }
        return lista;
    }
    //Cantidad de registros de la tabla. 
    public int contar() throws SQLException {
        try (PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) FROM productos");
             ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    //Confirma los cambios pendientes (COMMIT). 
    public void confirmar() throws SQLException {
        con.commit();
    }

    //Descarta los cambios pendientes (ROLLBACK). 
    public void revertir() throws SQLException {
        con.rollback();
    }

    //Datos de ejemplo para poder probar las consultas del Ejercicio 2
    public static List<Producto> ejemplos() {
        List<Producto> l = new ArrayList<>();
        l.add(new Producto("Laptop Lenovo IdeaPad", "Computo",    2450.00));
        l.add(new Producto("Mouse inalambrico",     "Accesorios",   45.90));
        l.add(new Producto("Teclado mecanico",      "Accesorios",  189.00));
        l.add(new Producto("Monitor LG 24 pulgadas","Computo",     699.50));
        l.add(new Producto("Impresora Epson L3250", "Impresion",   899.00));
        l.add(new Producto("Tinta Epson 544",       "Impresion",    39.90));
        l.add(new Producto("Disco SSD 500 GB",      "Almacenamiento", 215.00));
        l.add(new Producto("Memoria USB 64 GB",     "Almacenamiento",  29.00));
        l.add(new Producto("Webcam Full HD",        "Accesorios",   129.90));
        l.add(new Producto("Router TP-Link",        "Redes",        159.00));
        return l;
    }

    private Producto mapear(ResultSet rs) throws SQLException {
        return new Producto(rs.getInt("id"), rs.getString("nombre"),
                rs.getString("categoria"), rs.getDouble("precio"));
    }
}
