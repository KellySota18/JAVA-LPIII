@echo off
REM Compila el proyecto. Si falta el driver SQLite JDBC, lo descarga en lib\
if not exist lib\sqlite-jdbc-3.41.2.2.jar (
  echo Descargando driver SQLite JDBC...
  powershell -Command "Invoke-WebRequest -Uri 'https://repo1.maven.org/maven2/org/xerial/sqlite-jdbc/3.41.2.2/sqlite-jdbc-3.41.2.2.jar' -OutFile 'lib\sqlite-jdbc-3.41.2.2.jar'"
)
if not exist bin mkdir bin
javac -encoding UTF-8 -d bin src\*.java test\*.java
if errorlevel 1 ( echo ERROR de compilacion & exit /b 1 )
echo Compilacion correcta. Clases en la carpeta bin\
