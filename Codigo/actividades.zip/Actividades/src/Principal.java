import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class Principal {
    public static void main(String[] args) {
        try {
            Class.forName("org.sqlite.JDBC");

            Connection con = DriverManager.getConnection("jdbc:sqlite:ejemplo.db");

            if (con != null) {
                System.out.println("Se creó y/o abrió la base de datos con éxito.");
            }

            Statement stmt = con.createStatement();

            stmt.execute("CREATE TABLE IF NOT EXISTS emp (id INTEGER PRIMARY KEY, name TEXT, age INTEGER);");
            System.out.println("Creación de tabla exitosa.");

            stmt.executeUpdate("INSERT OR REPLACE INTO emp VALUES (1, 'Carlos', 25);");
            stmt.executeUpdate("INSERT OR REPLACE INTO emp VALUES (2, 'Bety', 30);");
            System.out.println("Inserción básica exitosa.");

            stmt.executeUpdate("UPDATE emp SET age = 28 WHERE id = 1;");
            System.out.println("Actualización exitosa.");

            stmt.executeUpdate("DELETE FROM emp WHERE id = 999;");

            System.out.println("\n--- Registros actuales (Statement) ---");
            ResultSet rs = stmt.executeQuery("SELECT * FROM emp;");
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt(1) + " | Nombre: " + rs.getString(2) + " | Edad: " + rs.getInt(3));
            }
            rs.close();

            System.out.println("\n--- Probando PreparedStatement ---");
            PreparedStatement pstmt = con.prepareStatement("INSERT OR REPLACE INTO emp VALUES (?, ?, ?);");
            pstmt.setInt(1, 3);
            pstmt.setString(2, "Laura");
            pstmt.setInt(3, 22);

            int filas = pstmt.executeUpdate();
            System.out.println(filas + " registro(s) insertado(s) con PreparedStatement.");
            pstmt.close();

            System.out.println("\n--- Probando Manejo de Transacciones ---");
            con.setAutoCommit(false);

            stmt.executeUpdate("INSERT OR REPLACE INTO emp VALUES (190, 'jose', 77);");
            stmt.executeUpdate("INSERT OR REPLACE INTO emp VALUES (191, 'diana', 88);");

            con.commit();
            System.out.println("Transacción confirmada correctamente (Commit).");

            System.out.println("\n--- Estado Final de la Base de Datos ---");
            ResultSet rsFinal = stmt.executeQuery("SELECT * FROM emp;");
            while (rsFinal.next()) {
                System.out.println("ID: " + rsFinal.getInt(1) + " | Nombre: " + rsFinal.getString(2) + " | Edad: " + rsFinal.getInt(3));
            }
            rsFinal.close();

            con.close();
            System.out.println("\nConexión cerrada correctamente.");

        } catch (Exception e) {
            System.out.println("Ocurrió un error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}



