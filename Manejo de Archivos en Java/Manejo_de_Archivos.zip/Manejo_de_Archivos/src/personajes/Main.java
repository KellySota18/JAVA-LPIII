package personajes;


public class Main {
    public static void main(String[] args) {
        Gestor gestor = new Gestor();
        gestor.anadirPersonaje("Caballero", 4, 2, 4, 2);
        gestor.anadirPersonaje("Guerrero", 2, 4, 2, 4);
        
        System.out.println("\n Lista Actual de Personajes ");
        gestor.mostrarPersonajes();
    }
}
