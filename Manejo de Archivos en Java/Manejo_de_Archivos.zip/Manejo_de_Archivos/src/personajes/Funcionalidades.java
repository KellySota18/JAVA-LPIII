package personajes;


public class Funcionalidades {

    public void filtrarPorAtaque(java.util.ArrayList<Personaje> listaPersonajes) {
        listaPersonajes.sort((p1, p2) -> Integer.compare(p2.getAtaque(), p1.getAtaque()));
        System.out.println("\n Personajes ordenados por mayor ataque");
        for (Personaje p : listaPersonajes) {
            System.out.println(p);
        }
    }

    public void mostrarEstadisticas(java.util.ArrayList<Personaje> listaPersonajes) {
        if (listaPersonajes.isEmpty()) {
            System.out.println("no hay estadísticas");
            return;
        }
        int total = listaPersonajes.size();
        double sumaVida = 0, sumaAtaque = 0, sumaDefensa = 0, sumaAlcance = 0;

        for (Personaje p : listaPersonajes) {
            sumaVida += p.getVida();
            sumaAtaque += p.getAtaque();
            sumaDefensa += p.getDefensa();
            sumaAlcance += p.getAlcance();
        }

        System.out.println("\n Estadisticas Generales ");
        System.out.println("Total de personajes: " + total);
        System.out.println("Promedio de Vida: " + (sumaVida / total));
        System.out.println("Promedio de Ataque: " + (sumaAtaque / total));
        System.out.println("Promedio de Defensa: " + (sumaDefensa / total));
        System.out.println("Promedio de Alcance: " + (sumaAlcance / total));
    }
}

