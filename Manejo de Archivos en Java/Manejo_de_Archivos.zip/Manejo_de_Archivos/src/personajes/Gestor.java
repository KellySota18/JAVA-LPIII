package personajes;

import java.io.*;
import java.util.ArrayList;

public class Gestor {
    private ArrayList<Personaje> listaPersonajes;
    private final String archivoNombre = "personajes.txt";

    public Gestor() {
        listaPersonajes = new ArrayList<>();
        cargarDesdeArchivo();
    }

    public void cargarDesdeArchivo() {
        File archivo = new File(archivoNombre);
        if (!archivo.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 5) {
                    String nombre = partes[0].trim();
                    int vida = Integer.parseInt(partes[1].trim());
                    int ataque = Integer.parseInt(partes[2].trim());
                    int defensa = Integer.parseInt(partes[3].trim());
                    int alcance = Integer.parseInt(partes[4].trim());
                    listaPersonajes.add(new Personaje(nombre, vida, ataque, defensa, alcance));
                }
            }
        } catch (IOException e) {
            System.out.println("error al cargar el archivo: " + e.getMessage());
        }
    }

    public void guardarEnArchivo() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(archivoNombre))) {
            for (Personaje p : listaPersonajes) {
                pw.println(p.getNombre() + "," + p.getVida() + "," + p.getAtaque() + "," + p.getDefensa() + "," + p.getAlcance());
            }
        } catch (IOException e) {
            System.out.println("eror al guardar: " + e.getMessage());
        }
    }

    public void anadirPersonaje(String nombre, int vida, int ataque, int defensa, int alcance) {
        for (Personaje p : listaPersonajes) {
            if (p.getNombre().equalsIgnoreCase(nombre)) {
                System.out.println("el personaje ya existe");
                return;
            }
        }
        if (vida > 0 && ataque > 0 && defensa > 0 && alcance > 0) {
            listaPersonajes.add(new Personaje(nombre, vida, ataque, defensa, alcance));
            guardarEnArchivo();
            System.out.println("personajes aniadidos");
        } else {
            System.out.println("los atributos tiene que ser mayores a cero");
        }
    }

    public void mostrarPersonajes() {
        if (listaPersonajes.isEmpty()) {
            System.out.println("no hay personajes");
        } else {
            for (Personaje p : listaPersonajes) {
                System.out.println(p);
            }
        }
    }

    public void borrarPersonaje(String nombre) {
        boolean eliminado = listaPersonajes.removeIf(p -> p.getNombre().equalsIgnoreCase(nombre));
        if (eliminado) {
            guardarEnArchivo();
            System.out.println("personaje eliminado");
        } else {
            System.out.println("no se encontro ese personaje");
        }
    }
}