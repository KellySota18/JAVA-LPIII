package contadores;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JFileChooser;

public class ContadorPalabras {
    public static void main(String[] args) {
        JFileChooser selector = new JFileChooser();
        int resultado = selector.showOpenDialog(null);

        if (resultado == JFileChooser.APPROVE_OPTION) {
            File archivo = selector.getSelectedFile();
            int lineas = 0, palabras = 0, caracteres = 0;

            try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
                String linea;
                while ((linea = br.readLine()) != null) {
                    lineas++;
                    caracteres += linea.length();
                    String[] tokens = linea.trim().split("\\s+");
                    if (!linea.trim().isEmpty()) {
                        palabras += tokens.length;
                    }
                }

                System.out.println("Total de líneas: " + lineas);
                System.out.println("Total de palabras: " + palabras);
                System.out.println("Total de caracteres: " + caracteres);
                if (lineas > 0) {
                    System.out.println("promedio de palabras: " + ((double) palabras / lineas));
                }

            } catch (IOException e) {
                System.out.println("error al leer archivo" + e.getMessage());
            }
        } else {
            System.out.println("cancelado");
        }
    }
}

