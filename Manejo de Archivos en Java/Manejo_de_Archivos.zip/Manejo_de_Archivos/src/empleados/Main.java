package empleados;

public class Main {
    public static void main(String[] args) {
        Controlador ctrl = new Controlador();
        ctrl.listarEmpleados();
    }
}

