package empleados;

import java.io.*;
import java.util.ArrayList;

public class Controlador {
    private ArrayList<Empleado> empleados = new ArrayList<>();
    private final String archivo = "empleados.txt";

    public void leerEmpleados() {
        empleados.clear();
        File f = new File(archivo);
        if (!f.exists()) return;

        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] datos = linea.split(",");
                if (datos.length == 3) {
                    int num = Integer.parseInt(datos[0].trim());
                    String nom = datos[1].trim();
                    double sue = Double.parseDouble(datos[2].trim());
                    empleados.add(new Empleado(num, nom, sue));
                }
            }
        } catch (IOException e) {
            System.out.println("error al leer empleados: " + e.getMessage());
        }
    }

    public void guardarEmpleados() {
        try (PrintWriter pw = new PrintWriter(new FileWriter(archivo))) {
            for (Empleado e : empleados) {
                pw.println(e.getNumero() + "," + e.getNombre() + "," + e.getSueldo());
            }
        } catch (IOException e) {
            System.out.println("error al guardar: " + e.getMessage());
        }
    }

    public void agregarEmpleado(int num, String nom, double sue) {
        leerEmpleados();
        empleados.add(new Empleado(num, nom, sue));
        guardarEmpleados();
        System.out.println("empleado agregado");
    }

    public void listarEmpleados() {
        leerEmpleados();
        if (empleados.isEmpty()) {
            System.out.println("no hay empleados");
        } else {
            for (Empleado e : empleados) {
                System.out.println(e);
            }
        }
    }

    public void buscarEmpleado(int num) {
        leerEmpleados();
        for (Empleado e : empleados) {
            if (e.getNumero() == num) {
                System.out.println("encontrado: " + e);
                return;
            }
        }
        System.out.println("empleado encontrado");
    }

    public void eliminarEmpleado(int num) {
        leerEmpleados();
        boolean eliminado = empleados.removeIf(e -> e.getNumero() == num);
        if (eliminado) {
            guardarEmpleados();
            System.out.println("empleado eliminado");	
        } else {
            System.out.println("no hay ningun empleado");
        }
    }
}

