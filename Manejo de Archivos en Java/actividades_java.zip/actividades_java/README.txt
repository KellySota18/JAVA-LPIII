Practica N° 07 - Manejo de Archivos en Java (Lenguajes de Programacion III)
Actividades 1 a 7 de la guia.

Estructura
  src/actividadN/   codigo de cada actividad (un paquete por actividad)
  datos/            archivos que leen/escriben los programas (agenda.txt, etc.)

Compilar (desde esta carpeta)
  javac -encoding UTF-8 -d out src/actividad*/*.java

Ejecutar (siempre desde esta carpeta, las rutas son relativas)
  java -cp out actividad1.TestFile
  java -cp out actividad2.Main
  java -cp out actividad3.Binarios2
  java -cp out actividad4.TestFilePrueba        (ventana grafica)
  java -cp out actividad5.AppContactos
  java -cp out actividad6.Serial5
  java -cp out actividad6.Serial6Lectura        (lee lo que escribio Serial5)
  java -cp out actividad7.PruebaJFileChooser    (ventana grafica)

Tambien se puede abrir la carpeta src en Eclipse/NetBeans/IntelliJ como proyecto.
