package actividad6;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

/**
 * Complemento de la actividad 6: lee los alumnos guardados por Serial5
 * para comprobar que la Fecha tambien se serializo correctamente.
 * Ejecutar primero Serial5.
 */
public class Serial6Lectura {

    public static void main(String[] args) {
        try (FileInputStream fis = new FileInputStream(Serial5.RUTA_ARCHIVO);
             ObjectInputStream entrada = new ObjectInputStream(fis)) {

            while (true) {
                Alumno a = (Alumno) entrada.readObject(); // casting necesario
                System.out.println(a);
            }
        } catch (EOFException e) {
            System.out.println("Fin del archivo");
        } catch (ClassNotFoundException e) {
            System.out.println("Clase no encontrada: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("Error al leer los alumnos (¿ejecutó Serial5 antes?): " + e.getMessage());
        }
    }
}
