package actividad6;

import java.io.Serializable;

/**
 * Fecha serializable. Debe implementar Serializable porque Alumno la contiene como atributo
 * (relacion de composicion): si no lo hiciera, writeObject lanzaria NotSerializableException.
 */
public class Fecha implements Serializable {

    private static final long serialVersionUID = 1L;

    private int dia;
    private int mes;
    private int anio;

    public Fecha(int dia, int mes, int anio) {
        this.dia = dia;
        this.mes = mes;
        this.anio = anio;
    }

    public Fecha() {
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    @Override
    public String toString() {
        return dia + "/" + mes + "/" + anio;
    }
}
