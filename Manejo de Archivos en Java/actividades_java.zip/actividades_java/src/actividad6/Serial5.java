package actividad6;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Actividad 6: Serializacion y relaciones de composicion entre clases.
 *
 * Escribe en un archivo tres objetos Alumno (subclase de Persona) que contienen
 * un atributo Fecha. Ejecutar desde la carpeta raiz del proyecto.
 */
public class Serial5 {

    static final String RUTA_ARCHIVO = "datos/alumnos.dat";

    public static void main(String[] args) {
        try {
            // Crea la carpeta "datos" si no existe
            Path carpeta = Paths.get(RUTA_ARCHIVO).getParent();
            if (carpeta != null) {
                Files.createDirectories(carpeta);
            }

            try (FileOutputStream fos = new FileOutputStream(RUTA_ARCHIVO);
                 ObjectOutputStream salida = new ObjectOutputStream(fos)) {

                Alumno a;
                Fecha f;

                f = new Fecha(5, 9, 2011);
                a = new Alumno("12345678A", "Lucas González", 20, f);
                salida.writeObject(a);

                f = new Fecha(7, 9, 2011);
                a = new Alumno("98765432B", "Anacleto Jiménez", 19, f);
                salida.writeObject(a);

                f = new Fecha(8, 9, 2011);
                a = new Alumno("78234212Z", "María Zapata", 21, f);
                salida.writeObject(a);
            }
            System.out.println("Se escribieron 3 alumnos en " + RUTA_ARCHIVO);
        } catch (IOException e) {
            System.out.println("Error al escribir los alumnos: " + e.getMessage());
        }
    }
}
