package actividad6;

/**
 * Alumno es una Persona que ademas tiene una fecha de matricula (atributo de tipo Fecha).
 */
public class Alumno extends Persona {

    private static final long serialVersionUID = 1L;

    private Fecha fechaMatricula;

    public Alumno(String nif, String nombre, int edad, Fecha fechaMatricula) {
        super(nif, nombre, edad);
        this.fechaMatricula = new Fecha();
        setFechaMatricula(fechaMatricula);
    }

    public Alumno() {
    }

    public Fecha getFechaMatricula() {
        return fechaMatricula;
    }

    /** Copia los valores de la fecha recibida (el alumno tiene su propia Fecha). */
    public void setFechaMatricula(Fecha fechaMatricula) {
        if (this.fechaMatricula == null) {
            this.fechaMatricula = new Fecha();
        }
        this.fechaMatricula.setDia(fechaMatricula.getDia());
        this.fechaMatricula.setMes(fechaMatricula.getMes());
        this.fechaMatricula.setAnio(fechaMatricula.getAnio());
    }

    @Override
    public String toString() {
        return getNif() + " " + getNombre() + " " + getEdad() + " matricula: " + fechaMatricula;
    }
}
