package actividad7;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 * Actividad 7: version grafica de la actividad 1.
 * El usuario elige con un JFileChooser el archivo o directorio y su informacion
 * se muestra en un JTextArea.
 */
public class DemoJFileChooser extends JFrame {

    private final JTextArea areaSalida;

    public DemoJFileChooser() throws IOException {
        super("Demo de JFileChooser");
        areaSalida = new JTextArea();
        areaSalida.setEditable(false);
        add(new JScrollPane(areaSalida)); // areaSalida cuenta con controles deslizables
        analizarRuta(); // obtiene el objeto Path del usuario y muestra la informacion
    }

    /** Muestra informacion del archivo o directorio seleccionado por el usuario. */
    public void analizarRuta() throws IOException {
        // Crea un objeto Path con la ruta al archivo o directorio seleccionado por el usuario
        Path ruta = obtenerRutaArchivoDirectorio();

        if (ruta != null && Files.exists(ruta)) {
            // StringBuilder para armar el texto que se mostrara
            StringBuilder builder = new StringBuilder();
            builder.append(String.format("%s:%n", ruta.getFileName()));
            builder.append(String.format("%s un directorio%n",
                    Files.isDirectory(ruta) ? "Es" : "No es"));
            builder.append(String.format("%s una ruta absoluta%n",
                    ruta.isAbsolute() ? "Es" : "No es"));
            builder.append(String.format("Ultima modificacion: %s%n", Files.getLastModifiedTime(ruta)));
            builder.append(String.format("Tamanio: %s%n", Files.size(ruta)));
            builder.append(String.format("Ruta: %s%n", ruta));
            builder.append(String.format("Ruta absoluta: %s%n", ruta.toAbsolutePath()));

            if (Files.isDirectory(ruta)) {
                builder.append(String.format("%nContenido del directorio:%n"));
                // Objeto para iterar a traves del contenido de un directorio
                try (DirectoryStream<Path> flujoDirectorio = Files.newDirectoryStream(ruta)) {
                    for (Path p : flujoDirectorio) {
                        builder.append(String.format("%s%n", p));
                    }
                }
            }

            areaSalida.setText(builder.toString()); // muestra el contenido del objeto String
        } else {
            String nombre = (ruta != null) ? ruta.getFileName().toString() : "La ruta";
            JOptionPane.showMessageDialog(this, nombre + " no existe.", "ERROR",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    /** Muestra el JFileChooser y devuelve el Path elegido (termina el programa si cancela). */
    private Path obtenerRutaArchivoDirectorio() {
        JFileChooser selectorArchivos = new JFileChooser();
        selectorArchivos.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
        int resultado = selectorArchivos.showOpenDialog(this);

        // Si el usuario hizo clic en el boton Cancelar en el cuadro de dialogo, regresa
        if (resultado == JFileChooser.CANCEL_OPTION) {
            System.exit(1);
        }

        // Devuelve objeto Path que representa el archivo seleccionado
        return selectorArchivos.getSelectedFile().toPath();
    }
}
