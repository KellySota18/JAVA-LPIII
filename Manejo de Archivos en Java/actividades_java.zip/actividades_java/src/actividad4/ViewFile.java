package actividad4;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 * Ventana que muestra el contenido de un archivo de texto dentro de un JTextArea.
 */
public class ViewFile extends JFrame {

    private JTextArea areaTexto;

    public ViewFile(String s) {
        super("Mostrando el contenido de un archivo");
        areaTexto = new JTextArea(s, 5, 40);
        areaTexto.setEditable(false);
        add(new JScrollPane(areaTexto)); // barras de desplazamiento si el texto es largo
    }
}
