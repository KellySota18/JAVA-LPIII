package actividad4;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/**
 * Actividad 4: Visualizando el contenido de un FileInputStream.
 *
 * Lee los primeros 1024 bytes de un archivo de texto y los muestra en un JTextArea.
 * Por defecto abre src/actividad1/TestFile.java; tambien se puede pasar otra ruta
 * como primer argumento. Ejecutar desde la carpeta raiz del proyecto.
 */
public class TestFilePrueba {

    private static final String RUTA_POR_DEFECTO = "src/actividad1/TestFile.java";

    public static void main(String[] args) {
        String ruta = (args.length > 0) ? args[0] : RUTA_POR_DEFECTO;
        byte[] b = new byte[1024];

        try (FileInputStream file = new FileInputStream(ruta)) {
            int leidos = file.read(b);
            // Se convierte solo la parte realmente leida (evita caracteres basura al final)
            String s = (leidos > 0) ? new String(b, 0, leidos) : "";

            SwingUtilities.invokeLater(() -> {
                ViewFile view = new ViewFile(s);
                view.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                view.setSize(600, 300);
                view.setVisible(true);
            });
        } catch (FileNotFoundException e) {
            System.out.println("No se encontro el archivo '" + ruta + "': " + e.getMessage());
        } catch (IOException e) {
            System.out.println("Error de lectura: " + e.getMessage());
        }
    }
}
