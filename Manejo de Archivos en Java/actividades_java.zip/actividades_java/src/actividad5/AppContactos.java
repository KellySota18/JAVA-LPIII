package actividad5;

/**
 * Actividad 5: Agenda de contactos leida desde un archivo.
 * Ejecutar desde la carpeta raiz del proyecto (usa datos/agenda.txt).
 */
public class AppContactos {

    public static void main(String[] args) {
        Agenda agenda = new Agenda();
        agenda.bucle();
    }
}
