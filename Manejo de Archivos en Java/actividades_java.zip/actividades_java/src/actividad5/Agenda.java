package actividad5;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/**
 * Carga los contactos de agenda.txt en un arreglo de Persona y permite buscarlos por nombre.
 *
 * El archivo guarda 3 lineas por contacto: nombre, telefono y direccion.
 */
public class Agenda {

    private static final String RUTA_AGENDA = "datos/agenda.txt";

    ArrayPersona lista;

    public Agenda() {
        this.lista = cargaContactos();
    }

    /** Pide nombres por teclado y muestra los datos del contacto. Termina con <Enter>. */
    public void bucle() {
        String nombre;
        System.out.println("Introduzca un nombre o <Enter>");
        try {
            while ((nombre = leeEntrada(System.in)) != null && !nombre.isEmpty()) {
                lista.printArray(nombre);
                System.out.println("Introduzca un nombre o <Enter>");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Lee una linea completa de un flujo de bytes (hasta '\n').
     * Devuelve null si ya no hay mas datos.
     */
    private String leeEntrada(InputStream entrada) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        int c;
        while ((c = entrada.read()) != -1 && c != '\n') {
            if (c != '\r') { // ignora el retorno de carro de Windows
                buffer.write(c);
            }
        }
        if (c == -1 && buffer.size() == 0) {
            return null; // fin del flujo
        }
        return new String(buffer.toByteArray(), StandardCharsets.UTF_8);
    }

    /** Lee un contacto (3 lineas) del archivo. Devuelve null al llegar al final. */
    private Persona cargaAgenda(InputStream agendaFile) throws IOException {
        String nombre = leeEntrada(agendaFile);
        if (nombre == null) {
            return null;
        }
        String telefono = leeEntrada(agendaFile);
        String direccion = leeEntrada(agendaFile);
        return new Persona(nombre, telefono, direccion);
    }

    private ArrayPersona cargaContactos() {
        ArrayPersona directorio = new ArrayPersona();
        Persona nuevaPersona;

        try (FileInputStream agendaFile = new FileInputStream(RUTA_AGENDA)) {
            while (true) {
                nuevaPersona = cargaAgenda(agendaFile);
                if (nuevaPersona == null) {
                    return directorio;
                }
                directorio.addArray(nuevaPersona);
            }
        } catch (FileNotFoundException e) {
            System.out.println("No hay archivo de agenda: " + RUTA_AGENDA);
        } catch (Exception e) {
            System.out.println("Error en la carga de los contactos");
            System.exit(1);
        }
        return directorio;
    }
}
