package actividad5;

/**
 * Arreglo de tamano fijo que almacena objetos Persona.
 */
public class ArrayPersona {

    public Persona[] arreglo;
    final int max = 128;
    int tamano = 0;

    public ArrayPersona() {
        this.arreglo = new Persona[this.max];
    }

    /** Muestra los datos de todas las personas cuyo nombre coincide con el buscado. */
    public void printArray(String nombre) {
        boolean encontrado = false;
        for (int i = 0; i < this.tamano; i++) {
            if (this.arreglo[i].getNombre().equalsIgnoreCase(nombre)) {
                System.out.println(this.arreglo[i]);
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("No se encontro el contacto: " + nombre);
        }
    }

    /** Agrega una persona al arreglo. Si esta lleno, termina el programa con un mensaje. */
    public void addArray(Persona persona) {
        if (this.tamano == max) {
            System.out.println("La agenda esta llena (maximo " + max + " contactos).");
            System.exit(1);
        }
        this.arreglo[this.tamano++] = persona;
    }
}
