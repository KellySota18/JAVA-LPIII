package actividad1;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

/**
 * Actividad 1: Obtener información de archivos y directorios.
 *
 * Pide al usuario la ruta de un archivo o directorio y muestra su información
 * usando las clases NIO Path, Paths y Files. Si es un directorio, lista su contenido.
 */
public class TestFile {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Escriba el nombre del archivo o directorio:");

        try {
            // Crear objeto Path con base en la entrada del usuario
            Path ruta = Paths.get(sc.nextLine());

            if (Files.exists(ruta)) {
                // Mostrar información del archivo (o directorio)
                System.out.printf("%n%s existe%n", ruta.getFileName());
                System.out.printf("%s un directorio%n",
                        Files.isDirectory(ruta) ? "Es" : "No es");
                System.out.printf("%s una ruta absoluta%n",
                        ruta.isAbsolute() ? "Es" : "No es");
                System.out.printf("Fecha de ultima modificacion: %s%n",
                        Files.getLastModifiedTime(ruta));
                System.out.printf("Tamanio: %s%n", Files.size(ruta));
                System.out.printf("Ruta: %s%n", ruta);
                System.out.printf("Ruta absoluta: %s%n", ruta.toAbsolutePath());

                if (Files.isDirectory(ruta)) {
                    System.out.printf("%nContenido del directorio:%n");

                    // Objeto para iterar en el contenido de un directorio.
                    // try-with-resources garantiza que el flujo se cierre.
                    try (DirectoryStream<Path> flujoDirectorio = Files.newDirectoryStream(ruta)) {
                        for (Path p : flujoDirectorio) {
                            System.out.println(p);
                        }
                    }
                }
            } else {
                System.out.printf("%s no existe%n", ruta);
            }
        } catch (InvalidPathException e) {
            System.out.println("La ruta ingresada no es valida: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("Error al leer la informacion: " + e.getMessage());
        } catch (java.util.NoSuchElementException e) {
            System.out.println("No se ingreso ninguna ruta.");
        }
    }
}
