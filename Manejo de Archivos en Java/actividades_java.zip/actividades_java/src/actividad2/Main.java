package actividad2;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

/**
 * Actividad 2: try-with-resources.
 *
 * Lee por teclado lineas de texto y las anade al final del archivo datos.txt.
 * El PrintWriter se cierra automaticamente al terminar el bloque try.
 */
public class Main {

    // El archivo queda en la carpeta "datos" del proyecto
    private static final String RUTA_ARCHIVO = "datos/datos.txt";

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String cadena;

        try {
            // Crea la carpeta "datos" si todavia no existe
            Path carpeta = Paths.get(RUTA_ARCHIVO).getParent();
            if (carpeta != null) {
                Files.createDirectories(carpeta);
            }

            // FileWriter con append=true: las lineas nuevas se anaden al final
            // sin borrar lo que ya hay en el archivo.
            try (PrintWriter salida = new PrintWriter(new FileWriter(RUTA_ARCHIVO, true))) { // try with resources
                System.out.println("Introduce texto. Para acabar introduce la cadena FIN:");
                cadena = sc.nextLine();
                while (!cadena.equalsIgnoreCase("FIN")) {
                    salida.println(cadena);
                    cadena = sc.nextLine();
                }
            }
            System.out.println("Texto guardado en " + RUTA_ARCHIVO);
        } catch (IOException e) {
            System.out.println("Error al escribir el archivo: " + e.getMessage());
        } catch (java.util.NoSuchElementException e) {
            System.out.println("Se termino la entrada sin escribir FIN. Lo ingresado hasta ahora fue guardado.");
        }
    }
}
