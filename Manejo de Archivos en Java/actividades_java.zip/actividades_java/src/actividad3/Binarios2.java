package actividad3;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * Actividad 3: Archivos binarios con DataOutputStream.
 *
 * Crea una matriz de double, lee sus elementos por teclado y la escribe en un archivo
 * binario. Al principio del archivo se guardan dos enteros: numero de filas y de columnas.
 * Al final se vuelve a leer el archivo para comprobar que se escribio correctamente.
 */
public class Binarios2 {

    private static final String RUTA_ARCHIVO = "datos/matriz.dat";

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        double[][] matriz;
        int filas, columnas, i, j;

        try {
            do {
                System.out.print("Numero de filas: ");
                filas = sc.nextInt();
            } while (filas <= 0);

            do {
                System.out.print("Numero de columnas: ");
                columnas = sc.nextInt();
            } while (columnas <= 0);

            matriz = new double[filas][columnas]; // se crea la matriz

            // Lectura de datos por teclado
            for (i = 0; i < filas; i++) {
                for (j = 0; j < columnas; j++) {
                    System.out.print("matriz[" + i + "][" + j + "]: ");
                    matriz[i][j] = sc.nextDouble();
                }
            }
        } catch (InputMismatchException e) {
            System.out.println("Entrada no valida: se esperaba un numero.");
            return;
        }

        escribirMatriz(matriz, RUTA_ARCHIVO);
        leerMatriz(RUTA_ARCHIVO);
    }

    /** Escribe filas, columnas y luego todos los elementos de la matriz. */
    private static void escribirMatriz(double[][] matriz, String ruta) {
        try {
            // Crea la carpeta "datos" si no existe
            Path carpeta = Paths.get(ruta).getParent();
            if (carpeta != null) {
                Files.createDirectories(carpeta);
            }

            try (FileOutputStream fos = new FileOutputStream(ruta);
                 DataOutputStream salida = new DataOutputStream(fos)) {

                // Escribir el numero de filas y columnas en el fichero (una sola vez)
                salida.writeInt(matriz.length);
                salida.writeInt(matriz[0].length);

                // Escribir la matriz en el fichero
                for (int i = 0; i < matriz.length; i++) {
                    for (int j = 0; j < matriz[i].length; j++) {
                        salida.writeDouble(matriz[i][j]);
                    }
                }
            }
            System.out.println("Matriz guardada en " + ruta);
        } catch (IOException e) {
            System.out.println("Error al escribir la matriz: " + e.getMessage());
        }
    }

    /** Lee el archivo binario y muestra la matriz (comprobacion de la escritura). */
    private static void leerMatriz(String ruta) {
        try (FileInputStream fis = new FileInputStream(ruta);
             DataInputStream entrada = new DataInputStream(fis)) {

            int filas = entrada.readInt();
            int columnas = entrada.readInt();
            System.out.println("\nContenido del archivo (" + filas + " x " + columnas + "):");

            for (int i = 0; i < filas; i++) {
                for (int j = 0; j < columnas; j++) {
                    System.out.print(entrada.readDouble() + "\t");
                }
                System.out.println();
            }
        } catch (IOException e) {
            System.out.println("Error al leer la matriz: " + e.getMessage());
        }
    }
}
